<div class="row d-flex" style="align-items:center; justify-content: center;">
    <div class="col-8 border-box mt-3">
        <div class="row">
            <div class="col-12">
                <h4 style="color:red;">Aviso!</h4>
                <hr style="border: 1px solid black;" />
            </div>

            <div class="col-12">
                <p>Esta vista estará habilitada cuando se te designe algun asesor para el curso.
                    Si existe algun inconveniente y/o queja envia un correo a <a href="#">example@unitru.edu.pe</u>
                    </a> para mas información.</p>
            </div>
        </div>
    </div>
</div>
