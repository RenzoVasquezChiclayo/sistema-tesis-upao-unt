<a href="/inicioP">Inicio</a>
@auth
<a href="/dashboard">Dashboard</a>
<a href="#">Logout</a>
@else
<a href="/">Login</a>
@endauth
