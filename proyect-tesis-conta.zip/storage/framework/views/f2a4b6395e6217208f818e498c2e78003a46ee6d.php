<?php if(auth()->guard()->check()): ?>
    <li>
        <a href="<?php echo e(route('user_information')); ?>">
            <i class='bx bx-sm bx-user-circle'></i>
            <span class="links_name">Perfil</span>
        </a>
        <span class="tooltip">Perfil</span>
    </li>
    <li>
        <a href="<?php echo e(route('user_reports')); ?>">
            <i class='bx bxs-report'></i>
            <span class="links_name">Reportes</span>
        </a>
        <span class="tooltip">Reportes</span>
    </li>

    
    <?php if(auth()->user()->rol == 'estudiante'): ?>
        <li>
            <a href="<?php echo e(route('egresadoindex')); ?>">
                <i class='bx bx-sm bx-memory-card'></i>
                <span class="links_name">Formato del Egresado</span>
            </a>
            <span class="tooltip">Egresado</span>
        </li>
        <li>
            <a href="<?php echo e(route('index')); ?>">
                <i class='bx bx-sm bx-book-bookmark'></i>
                <span class="links_name">Proyecto de Tesis</span>
            </a>
            <span class="tooltip">Proyecto de Tesis</span>
        </li>
        
        
        <li>
            <a href="<?php echo e(route('verRegistroHistorial')); ?>">
                <i class='bx bx-sm bx-history'></i>
                <span class="links_name">Historial de Correcciones</span>
            </a>
            <span class="tooltip">Correcciones</span>
        </li>

    
    <?php elseif(auth()->user()->rol == 'director'): ?>
        <li>
            <a href="<?php echo e(route('director.formatos')); ?>">
                <i class='bx bx-sm bx-memory-card'></i>
                <span class="links_name">Formatos de titulos</span>
            </a>
            <span class="tooltip">Formatos de titulos</span>
        </li>

    
    <?php elseif(auth()->user()->rol == 'asesor'): ?>
        <li>
            <a href="<?php echo e(route('asesor.proyectos')); ?>">
                <i class="nav-icon fas fa-graduation-cap"></i>
                <span class="links_name">Proyectos de tesis</span>
            </a>
            <span class="tooltip">Proyectos de tesis</span>
        </li>
        <li>
            <a href="<?php echo e(route('asesor.historial_observaciones')); ?>">
                <i class='bx bx-sm bx-history'></i>
                <span class="links_name">Historial de Observaciones</span>
            </a>
            <span class="tooltip">Observaciones</span>
        </li>

    
    <?php elseif(auth()->user()->rol == 'docente'): ?>
        <li>
            <a href="<?php echo e(route('docente.showSilabos')); ?>">
                <i class="nav-icon fas fa-graduation-cap"></i>
                <span class="links_name">Silabo</span>
            </a>
            <span class="tooltip">Silabo</span>
        </li>

    
    <?php elseif(auth()->user()->rol == 'CTesis2022-1'): ?>

        <li>
            <a href="<?php echo e(route('curso.tesis20221')); ?>">
                <i class='bx bx-sm bx-book-bookmark'></i>
                <span class="links_name">Proyecto Tesis</span>
            </a>
            <span class="tooltip">Proyecto Tesis</span>
        </li>
        <li>
            <a href="<?php echo e(route('curso.estado-proyecto')); ?>">
                <i class='bx bx-sm bx-battery'></i>
                <span class="links_name">Estado del Proyecto</span>
            </a>
            <span class="tooltip">Estado del Proyecto</span>
        </li>
        <li>
            <a href="<?php echo e(route('curso.registro-tesis')); ?>">
                <i class='bx bxs-graduation'></i>
                <span class="links_name">Tesis</span>
            </a>
            <span class="tooltip">Tesis</span>
        </li>
        <li>
            <a href="<?php echo e(route('curso.estado-tesis')); ?>">
                <i class='bx bx-sm bx-battery'></i>
                <span class="links_name">Estado de la Tesis</span>
            </a>
            <span class="tooltip">Estado de la Tesis</span>
        </li>
        

    
    <?php elseif(auth()->user()->rol == 'd-CTesis2022-1' || auth()->user()->rol == 'administrador'): ?>
        <?php if(auth()->user()->rol == 'administrador'): ?>
            <li>
                <a href="<?php echo e(route('admin.listar')); ?>">
                    <i class='bx bxs-user'></i>
                    <span class="links_name">Listar Usuarios</span>
                </a>
                <span class="tooltip">Listar Usuarios</span>
            </li>
        <?php endif; ?>
        <li>
            <a href="<?php echo e(route('director.listaAlumnos')); ?>">
                <i class='bx bx-sm bx-list-ol'></i>
                <span class="links_name">Lista Alumnos</span>
            </a>
            <span class="tooltip">Lista Alumnos</span>
        </li>
        <li>
            <a href="<?php echo e(route('director.veragregarAsesor')); ?>">
                <i class='bx bx-sm bx-message-square-add'></i>
                <span class="links_name">Agregar Asesor</span>
            </a>
            <span class="tooltip">Asesor</span>
        </li>
        <li>
            <a href="<?php echo e(route('director.veragregar')); ?>">
                <i class='bx bx-sm bx-message-square-add'></i>
                <span class="links_name">Agregar Alumno</span>
            </a>
            <span class="tooltip">Alumno</span>
        </li>
        <li>
            <div class="links_name" style="border: solid white; border-width: 1px 0px 0px 0px; margin-left:15px;">
                <p style="color: white;">Asignar Asesor</p>
            </div>
        </li>
        <li>
            <a href="<?php echo e(route('director.asignar')); ?>">
                <i class='bx bx-sm bx-check-square'></i>
                <span class="links_name">Proyecto de Tesis</span>
            </a>
            <span class="tooltip">Proyecto de Tesis</span>
        </li>
        <li>
            <a href="<?php echo e(route('director.asignarAsesorTesis')); ?>">
                <i class='bx bx-sm bx-check-square'></i>
                <span class="links_name">Tesis</span>
            </a>
            <span class="tooltip">Tesis</span>
        </li>

        
    <?php elseif(auth()->user()->rol == 'a-CTesis2022-1'): ?>
        <li>
            <a href="<?php echo e(route('asesor.showEstudiantes')); ?>">
                <i class='bx bx-sm bx-group'></i>
                <span class="links_name">Estudiantes Proyecto</span>
            </a>
            <span class="tooltip">Estudiantes</span>
        </li>
        <li>
            <a href="<?php echo e(route('asesor.verHistoObs')); ?>">
                <i class='bx bx-sm bx-history'></i>
                <span class="links_name">Historial Proyecto</span>
            </a>
            <span class="tooltip">Observaciones</span>
        </li>
        <li>
            <a href="<?php echo e(route('asesor.estudiantes-tesis')); ?>">
                <i class='bx bx-sm bx-group'></i>
                <span class="links_name">Estudiantes Tesis</span>
            </a>
            <span class="tooltip">Estudiantes</span>
        </li>
        <li>
            <a href="<?php echo e(route('asesor.ver-estudsiantes-obs')); ?>">
                <i class='bx bx-sm bx-history'></i>
                <span class="links_name">Historial Tesis</span>
            </a>
            <span class="tooltip">Estudiantes</span>
        </li>


        
        
    <?php endif; ?>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\proyect-tesis-conta\resources\views/plantilla/nav.blade.php ENDPATH**/ ?>