
<?php $__env->startSection('titulo'); ?>
    Estudiantes con Proyectos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-12">
        <div class="row" style="display: flex; align-items:center;">
            <div class="col-8">
                <h2>En proceso</h2>
                    <table id="table-proyecto" class="table table-striped table-responsive-md">
                        <thead>
                            <tr>
                                <td>Numero Matricula</td>
                                <td>DNI</td>
                                <td>Nombres</td>
                                <td>Revision</td>
                                <td>Descargar</td>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr
                                <?php if($estu->estado == 3): ?>
                                    style="background-color: #7BF96E;"
                                <?php elseif($estu->estado == 4): ?>
                                    style="background-color: #FA6A56;"
                                <?php endif; ?>
                                >
                                    <td><?php echo e($estu->cod_matricula); ?></td>
                                    <td><?php echo e($estu->dni); ?></td>
                                    <td><?php echo e($estu->nombres.' '.$estu->apellidos); ?></td>
                                    <td>
                                        <?php if($estu->estado != 0): ?>
                                            <form id="form-revisaTema" action="<?php echo e(route('asesor.revisarTemas')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="cod_matricula" value="<?php echo e($estu->cod_matricula); ?>">
                                                <?php if($estu->estado == 1): ?>
                                                    <a href="#" onclick="this.closest('#form-revisaTema').submit()" class="btn btn-success">Revisar</a>
                                                <?php else: ?>
                                                    <a href="#" onclick="this.closest('#form-revisaTema').submit()" class="btn btn-secondary">Observar</a>
                                                <?php endif; ?>
                                            </form>
                                        <?php endif; ?>
                                        
                                    </td>
                                    <td style="text-align: center;">
                                        <form id="proyecto-download" action="<?php echo e(route('curso.descargaTesis')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="cod_cursoTesis" value="<?php echo e($estu->cod_proyectotesis); ?>">
                                            <a href="#" onclick="this.closest('#proyecto-download').submit()"><i class='bx bx-sm bx-download'></i></a>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <?php if(session('datos')=='ok'): ?>
        <script>
            Swal.fire(
                'Guardado!',
                'Asignacion de campos guardados correctamente',
                'success'
            )
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyect-tesis-conta\resources\views/cursoTesis20221/asesor/showEstudiantes.blade.php ENDPATH**/ ?>